//
//  ViewController.h
//  EX_1_2_1
//
//  Created by SDT-1 on 2014. 1. 9..
//  Copyright (c) 2014년 steve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
